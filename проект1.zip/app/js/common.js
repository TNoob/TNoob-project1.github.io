$(document).ready(function(){
	$('.dropdown').hide();
	$('.burger').click(function(){
		$('.dropdown').slideToggle(600);
	});




	$('.info').hide();
	$('.more').click(function(){
		
		
		var $info = $(this).next('.info');
		if ($info.is(':hidden')){
			$info.fadeIn(600);
			$(this).addClass('new-more');
		}
		else{
			$info.fadeOut(600);
			$(this).removeClass('new-more');
		}
	});
});