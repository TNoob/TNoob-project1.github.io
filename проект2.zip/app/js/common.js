$(document).ready(function(){
	$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        }
    }
})
	$('.owl-prev').html('<i class="fa fa-chevron-circle-left" aria-hidden="true"></i>');
	$('.owl-next').html('<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>');



	var pattern = /^[a-z0-9_-]+@[a-z]+\.[a-z]{2,6}$/i;
	var mail = $('#mail');

	mail.blur(function(){
		if(mail.val() != ''){
				if(mail.val().search(pattern) == 0){
					$('#valid').text('OK!');
					$('#submit').attr('disabled', false);
					mail.removeClass('error').addClass('ok');
				}else{
					$('#valid').text('Sorry, try again!');
					$('#submit').attr('disabled', true);
					mail.addClass('ok');
				}
			}else{
				$('#valid').text('Please, write your e-mail!');
				mail.addClass('error');
				$('#submit').attr('disabled', true);
			}
	});
});